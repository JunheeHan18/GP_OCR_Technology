package com.example.junhe.ocr;

import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import data.BookmarkData;
import data.BookmarkResponse;
import data.SignupResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookmarkActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmark);

//        List<ListItem> mylist = new ArrayList<>();
        ListView listview ;
        final bookmarkAdapter adapter;

        // Adapter 생성
        adapter = new bookmarkAdapter();

        // 리스트뷰 참조 및 Adapter달기
        listview = (ListView) findViewById(R.id.bmList);
        listview.setAdapter(adapter);
//        추가코드
//        private void makeList(BookmarkData data) {
//            service.bookmark(data).enqueue(new Callback<BookmarkResponse>() {
//                @Override
//                public void onResponse(Call<BookmarkResponse> call, Response<BookmarkResponse> response) {
//                    if(response.isSuccessful()) {//check for Response status
//                        BookmarkResponse result = response.body();
//                        while(!result.getTitle().isEmpty()) {
//                            adapter.addItem(result.getTitle(), result.getTitle(), result.getDate().toString());
//                        }
//                    }
//                }
//            }
//        }
        adapter.addItem("제목1","북마크한 내용입니다.","2020.01.01");
        adapter.addItem("제목2","북마크한 내용입니다.","2020.01.01");
        adapter.addItem("제목3","북마크한 내용입니다.","2020.01.01");

    }


}
