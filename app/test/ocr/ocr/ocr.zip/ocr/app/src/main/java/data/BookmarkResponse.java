package data;

import com.google.gson.annotations.SerializedName;

import java.sql.Date;

import javax.xml.transform.Result;

import retrofit2.Call;

public class BookmarkResponse {
        @SerializedName("title")
        private String title;

        @SerializedName("content")
        private String content;

        @SerializedName("date")
        private Date date;

        public String getTitle() {
            return title;
        }
        public String getContent() {
            return content;
        }
        public java.sql.Date getDate() {
            return date;
        }

    }

//참고사이트("https://ppizil.tistory.com/27")