package com.example.junhe.ocr;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;



import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class MainActivity extends AppCompatActivity {
    Socket socket;
    final int NORMALMODE = 101;
    final int READINGMODE = 102;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn_Nomal = (Button)findViewById(R.id.btn_normalmode);
        Button btn_Reading = (Button)findViewById(R.id.btn_readingmode);



        //서버 소켓연결 부분
        try {
            socket = IO.socket("http://52.78.200.48:4000");
        }catch (Exception e) {
            e.printStackTrace();
        }

        socket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                socket.emit("message_from_client", "Android Connected...");
            }
        }).on("message_from_server", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, args[0].toString(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        socket.connect();


        btn_Nomal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mode = NORMALMODE;
                socket.emit("set_to_normal", mode);
            }
        });

        btn_Reading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mode = READINGMODE;
                socket.emit("set_to_reading",mode);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()){
            case R.id.menu_tranform:
                Intent intent = new Intent(getApplicationContext(),TransActivity.class);
                startActivity(intent);
                break;
            case R.id.menu_bookmark:
                Intent intent1 = new Intent(getApplicationContext(),BookmarkActivity.class);
                startActivity(intent1);
                break;
            case R.id.menu_signin:
                Intent intent2 = new Intent(getApplicationContext(),SigninActivity.class);
                startActivity(intent2);
                break;
            case R.id.menu_signup:
                Intent intent3 = new Intent(getApplicationContext(),SignupActivity.class);
                startActivity(intent3);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
}
